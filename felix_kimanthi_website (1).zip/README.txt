FELIX M. KIMANTHI — EXECUTIVE PROFILE WEBSITE
==============================================

CONTENTS
- index.html: website content and structure
- styles.css: responsive design and layout
- script.js: mobile navigation and current footer year
- assets/felix-kimanthi.jpg: supplied portrait
- assets/ochl-logo.png: supplied Olympia Capital Holdings logo

PREVIEW LOCALLY
1. Extract the ZIP file.
2. Open index.html in a modern web browser.
3. Internet access is needed for the optional Google Fonts. The site otherwise works locally.

PUBLISHING
Upload the extracted folder contents to a web host (for example, the OCHL website host or a static host). The home page is index.html.

IMPORTANT EDITORIAL NOTES
- This is a draft profile website for review, not a published site.
- Career and qualification details were drafted from the supplied profile and OCHL's public executive profile.
- Confirm earlier-career dates and titles before publication.
- The contact section routes to the official OCHL website and general corporate email; it does not publish personal phone numbers.
- The supplied OCHL logo and the provided LinkedIn profile link have been added.
- Check current company naming, title, profile details and image permissions before going live.
